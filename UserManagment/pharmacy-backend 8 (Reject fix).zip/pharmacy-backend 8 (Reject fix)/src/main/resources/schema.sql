-- Make description column nullable in medicines table
ALTER TABLE medicines MODIFY COLUMN description VARCHAR(500) NULL;

-- Set default value for stock_quantity
ALTER TABLE medicines MODIFY COLUMN stock_quantity INT NOT NULL DEFAULT 0; 
package com.pharmacy.controller;

import com.pharmacy.model.Cart;
import com.pharmacy.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin(origins = "*")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping
    public Cart createCart() {
        return cartService.createCart();
    }

    @GetMapping("/{cartId}")
    public Cart getCart(@PathVariable Long cartId) {
        return cartService.getCart(cartId);
    }

    @PostMapping("/{cartId}/items")
    public Cart addItem(@PathVariable Long cartId, @RequestParam Long medicineId, @RequestParam int quantity) {
        return cartService.addItemToCart(cartId, medicineId, quantity);
    }

    @DeleteMapping("/{cartId}/items/{medicineId}")
    public Cart removeItem(@PathVariable Long cartId, @PathVariable Long medicineId) {
        return cartService.removeItemFromCart(cartId, medicineId);
    }

    @PutMapping("/{cartId}/items/{medicineId}")
    public Cart updateQuantity(@PathVariable Long cartId, @PathVariable Long medicineId, @RequestParam int quantity) {
        return cartService.updateItemQuantity(cartId, medicineId, quantity);
    }

    @DeleteMapping("/{cartId}")
    public Cart clearCart(@PathVariable Long cartId) {
        return cartService.clearCart(cartId);
    }
}

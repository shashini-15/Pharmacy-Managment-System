package com.pharmacy.controller.admin;

import com.pharmacy.model.Medicine;
import com.pharmacy.service.MedicineService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/medicines")
@CrossOrigin(origins = "*")
public class AdminMedicineController {

    private static final Logger logger = LoggerFactory.getLogger(AdminMedicineController.class);

    @Autowired
    private MedicineService medicineService;

    @PostMapping
    public ResponseEntity<?> createMedicine(@RequestBody Medicine medicine) {
        try {
            logger.info("Received request to create medicine: {}", medicine);
            
            if (medicine == null) {
                logger.error("Medicine object is null");
                return ResponseEntity.badRequest().body("Medicine object cannot be null");
            }

            Medicine createdMedicine = medicineService.createMedicine(medicine);
            return ResponseEntity.ok(createdMedicine);
        } catch (Exception e) {
            logger.error("Error creating medicine: {}", e.getMessage());
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping
    public List<Medicine> getAllMedicines() {
        return medicineService.getAllMedicines();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Medicine> getMedicineById(@PathVariable Long id) {
        return medicineService.getMedicineById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateMedicine(@PathVariable Long id, @RequestBody Medicine medicineDetails) {
        try {
            logger.info("Received request to update medicine with ID: {}", id);
            Medicine updatedMedicine = medicineService.updateMedicine(id, medicineDetails);
            logger.info("Medicine updated successfully");
            return ResponseEntity.ok(updatedMedicine);
        } catch (IllegalArgumentException e) {
            logger.error("Validation error: {}", e.getMessage());
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            logger.error("Error updating medicine: {}", e.getMessage());
            return ResponseEntity.internalServerError().body("Error updating medicine: " + e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteMedicine(@PathVariable Long id) {
        try {
            logger.info("Received request to delete medicine with ID: {}", id);
            medicineService.deleteMedicine(id);
            logger.info("Medicine deleted successfully");
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            logger.error("Error deleting medicine: {}", e.getMessage());
            return ResponseEntity.internalServerError().body("Error deleting medicine: " + e.getMessage());
        }
    }
} 
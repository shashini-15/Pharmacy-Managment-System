package com.pharmacy.controller.pharmacist;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/pharmacist/prescriptions")
public class PrescriptionUploadController {
    private static final Logger logger = LoggerFactory.getLogger(PrescriptionUploadController.class);

    @Value("${app.prescription.upload.dir:prescriptions}")
    private String prescriptionUploadDir;

    @PostMapping("/upload")
    public ResponseEntity<?> uploadPrescription(@RequestParam("file") MultipartFile file) {
        try {
            // Create upload directory if it doesn't exist
            Path uploadPath = Paths.get(prescriptionUploadDir).toAbsolutePath();
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            // Generate unique filename
            String originalFilename = file.getOriginalFilename();
            String extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            String filename = UUID.randomUUID().toString() + extension;
            Path filePath = uploadPath.resolve(filename);

            // Save file
            Files.copy(file.getInputStream(), filePath);

            // Return the URL path
            String prescriptionUrl = "/prescriptions/" + filename;
            Map<String, String> response = new HashMap<>();
            response.put("prescriptionUrl", prescriptionUrl);

            logger.info("Prescription uploaded successfully: {}", prescriptionUrl);
            return ResponseEntity.ok(response);
        } catch (IOException e) {
            logger.error("Failed to upload prescription: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().body("Failed to upload prescription: " + e.getMessage());
        }
    }

    @GetMapping("/{filename}")
    public ResponseEntity<?> getPrescription(@PathVariable String filename) {
        try {
            Path filePath = Paths.get(prescriptionUploadDir).resolve(filename);
            if (!Files.exists(filePath)) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok().body(Files.readAllBytes(filePath));
        } catch (IOException e) {
            logger.error("Failed to retrieve prescription: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().body("Failed to retrieve prescription: " + e.getMessage());
        }
    }
} 
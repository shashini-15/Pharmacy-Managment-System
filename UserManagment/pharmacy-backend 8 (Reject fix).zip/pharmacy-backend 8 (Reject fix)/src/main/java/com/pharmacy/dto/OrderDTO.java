package com.pharmacy.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.util.List;

@Data
public class OrderDTO {
    private String customerName;
    private String customerEmail;
    private String customerPhone;
    private String deliveryAddress;
    private List<OrderItemDTO> orderItems;
    private BigDecimal totalAmount;
    private String status;

    @Data
    public static class OrderItemDTO {
        private MedicineDTO medicine;
        private Integer quantity;
        private BigDecimal price;
    }

    @Data
    public static class MedicineDTO {
        private Long id;
    }
} 
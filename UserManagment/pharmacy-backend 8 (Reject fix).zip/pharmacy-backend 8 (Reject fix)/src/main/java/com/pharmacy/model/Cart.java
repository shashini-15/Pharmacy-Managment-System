package com.pharmacy.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "carts")
@Data
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<CartItem> items = new ArrayList<>();

    @Column(nullable = false)
    private BigDecimal totalAmount = BigDecimal.ZERO;

    public void addItem(Medicine medicine, int quantity) {
        CartItem existingItem = items.stream()
            .filter(item -> item.getMedicine().getId().equals(medicine.getId()))
            .findFirst()
            .orElse(null);

        if (existingItem != null) {
            existingItem.setQuantity(existingItem.getQuantity() + quantity);
        } else {
            CartItem newItem = new CartItem(this, medicine, quantity);
            items.add(newItem);
        }
        calculateTotal();
    }

    public void removeItem(Long medicineId) {
        items.removeIf(item -> item.getMedicine().getId().equals(medicineId));
        calculateTotal();
    }

    public void updateQuantity(Long medicineId, int quantity) {
        items.stream()
            .filter(item -> item.getMedicine().getId().equals(medicineId))
            .findFirst()
            .ifPresent(item -> {
                item.setQuantity(quantity);
                calculateTotal();
            });
    }

    private void calculateTotal() {
        totalAmount = items.stream()
            .map(item -> item.getMedicine().getPrice().multiply(new BigDecimal(item.getQuantity())))
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public void clear() {
        items.clear();
        totalAmount = BigDecimal.ZERO;
    }
} 
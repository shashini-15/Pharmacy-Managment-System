package com.pharmacy.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "medicines")
@Data
public class Medicine {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Medicine name is required")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    @Column(nullable = false)
    private String name;

    @Size(max = 500, message = "Description must be less than 500 characters")
    @Column(nullable = true)
    private String description;

    @NotNull(message = "Price is required")
    @DecimalMin(value = "0.01", message = "Price must be greater than 0")
    @Column(nullable = false)
    private BigDecimal price;

    @NotNull(message = "Stock quantity is required")
    @Min(value = 0, message = "Stock quantity cannot be negative")
    @Column(name = "stock", nullable = false)
    private Integer stockQuantity;

    @NotBlank(message = "Category is required")
    @Column(nullable = false)
    private String category; // e.g., Pain Relief, Antibiotics, etc.

    @Column
    private String manufacturer;

    @Column
    private String imageUrl;

    @Column(name = "expiry_date")
    private LocalDate expiryDate;

    @NotNull(message = "Prescription requirement must be specified")
    @Column(nullable = false)
    private Boolean requiresPrescription;

    // Default constructor
    public Medicine() {
    }

    // Constructor
    public Medicine(String name, String description, BigDecimal price, String category, 
                   Boolean requiresPrescription, String imageUrl, Integer stockQuantity, LocalDate expiryDate) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.category = category;
        this.requiresPrescription = requiresPrescription;
        this.imageUrl = imageUrl;
        this.stockQuantity = stockQuantity;
        this.expiryDate = expiryDate;
    }

    // Getters 
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(Integer stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Boolean isRequiresPrescription() {
        return requiresPrescription;
    }

    public void setRequiresPrescription(Boolean requiresPrescription) {
        this.requiresPrescription = requiresPrescription;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }
} 
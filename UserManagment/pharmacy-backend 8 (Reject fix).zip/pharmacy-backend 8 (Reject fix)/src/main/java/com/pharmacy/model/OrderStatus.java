package com.pharmacy.model;

public enum OrderStatus {
    PENDING_APPROVAL,
    APPROVED,
    PROCESSING,
    SHIPPED,
    DELIVERED,
    CANCELLED
} 
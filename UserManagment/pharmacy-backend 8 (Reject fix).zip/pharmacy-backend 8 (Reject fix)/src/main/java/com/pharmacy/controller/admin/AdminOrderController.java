package com.pharmacy.controller.admin;

import com.pharmacy.model.Order;
import com.pharmacy.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin/orders")
@CrossOrigin(origins = "*")
public class AdminOrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping
    public List<Order> getAllOrders() {
        return orderService.getAllOrders();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable Long id) {
        return orderService.getOrderById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Order createOrder(@RequestBody Order order) {
        return orderService.createOrder(order);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Order> updateOrder(@PathVariable Long id, @RequestBody Order orderDetails) {
        try {
            Order updatedOrder = orderService.updateOrder(id, orderDetails);
            return ResponseEntity.ok(updatedOrder);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable Long id) {
        orderService.deleteOrder(id);
        return ResponseEntity.ok().build();
    }

    // View Prescriptions Report
    @GetMapping("/prescriptions/report")
    public Map<String, Object> getPrescriptionsReport() {
        List<Order> allOrders = orderService.getAllOrders();
        
        // Calculate statistics
        long totalOrders = allOrders.size();
        long ordersWithPrescription = allOrders.stream()
                .filter(order -> order.getPrescriptionImageUrl() != null)
                .count();
        
        // Group orders by status
        Map<String, Long> ordersByStatus = allOrders.stream()
                .collect(Collectors.groupingBy(
                    order -> order.getStatus().toString(),
                    Collectors.counting()
                ));

        Map<String, Object> report = new HashMap<>();
        report.put("totalOrders", totalOrders);
        report.put("ordersWithPrescription", ordersWithPrescription);
        report.put("ordersByStatus", ordersByStatus);
        report.put("prescriptionPercentage", 
            totalOrders > 0 ? (ordersWithPrescription * 100.0 / totalOrders) : 0);
        
        return report;
    }

    //Prescription Information
    @GetMapping("/prescriptions")
    public List<Map<String, Object>> getPrescriptionDetails() {
        return orderService.getAllOrders().stream()
                .filter(order -> order.getPrescriptionImageUrl() != null)
                .map(order -> {
                    Map<String, Object> details = new HashMap<>();
                    details.put("orderId", order.getId());
                    details.put("customerName", order.getCustomerName());
                    details.put("orderDate", order.getOrderDate());
                    details.put("status", order.getStatus());
                    details.put("prescriptionUrl", order.getPrescriptionImageUrl());
                    return details;
                })
                .collect(Collectors.toList());
    }
} 
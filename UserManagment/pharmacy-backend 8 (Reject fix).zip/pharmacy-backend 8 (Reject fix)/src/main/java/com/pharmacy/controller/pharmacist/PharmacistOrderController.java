package com.pharmacy.controller.pharmacist;

import com.pharmacy.model.Order;
import com.pharmacy.model.OrderStatus;
import com.pharmacy.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pharmacist/orders")
@CrossOrigin(origins = "*")
public class PharmacistOrderController {

    @Autowired
    private OrderService orderService;

    // Get single order by ID
    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable Long id) {
        try {
            return orderService.getOrderById(id)
                    .map(ResponseEntity::ok)
                    .orElse(ResponseEntity.notFound().build());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    // View Prescription
    @GetMapping("/{orderId}/prescription")
    public ResponseEntity<String> getPrescription(@PathVariable Long orderId) {
        try {
            Order order = orderService.getOrderById(orderId)
                    .orElseThrow(() -> new RuntimeException("Order not found"));
            
            if (order.getPrescriptionImageUrl() == null) {
                return ResponseEntity.notFound().build();
            }
            
            return ResponseEntity.ok(order.getPrescriptionImageUrl());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    // Approve or Reject Order
    @PutMapping("/{id}/review")
    public ResponseEntity<Order> reviewOrder(
            @PathVariable Long id,
            @RequestParam("action") String action) {
        try {
            Order order = orderService.getOrderById(id)
                    .orElseThrow(() -> new RuntimeException("Order not found"));

            // Only allow review of pending orders
            if (order.getStatus() != OrderStatus.PENDING_APPROVAL) {
                return ResponseEntity.badRequest().build();
            }

            // Update status based on action
            String newStatus = action.equalsIgnoreCase("approve") ? "APPROVED" : "CANCELLED";
            Order updatedOrder = orderService.updateOrderStatus(id, newStatus);
            
            if (updatedOrder == null) {
                return ResponseEntity.internalServerError().build();
            }
            
            return ResponseEntity.ok(updatedOrder);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // All Orders
    @GetMapping
    public ResponseEntity<List<Order>> getAllOrders() {
        try {
            List<Order> orders = orderService.getAllOrders();
            return ResponseEntity.ok(orders);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    // Orders by Status
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Order>> getOrdersByStatus(@PathVariable String status) {
        try {
            OrderStatus orderStatus = OrderStatus.valueOf(status.toUpperCase());
            List<Order> orders = orderService.getOrdersByStatus(orderStatus);
            return ResponseEntity.ok(orders);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
} 
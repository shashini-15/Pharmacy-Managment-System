package com.pharmacy.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home() {
        return "forward:/user/index.html";
    }

    @GetMapping("/admin")
    public String admin() {
        return "forward:/admin/index.html";
    }

    @GetMapping("/user")
    public String user() {
        return "forward:/user/index.html";
    }

    @GetMapping("/pharmacist")
    public String pharmacist() {
        return "forward:/pharmacist/index.html";
    }
} 
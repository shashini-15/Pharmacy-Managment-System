package com.pharmacy.controller.user;

import com.pharmacy.dto.OrderDTO;
import com.pharmacy.model.Order;
import com.pharmacy.model.OrderItem;
import com.pharmacy.model.Medicine;
import com.pharmacy.model.OrderStatus;
import com.pharmacy.service.OrderService;
import com.pharmacy.service.MedicineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/user/orders")
@CrossOrigin(origins = "*")
public class UserOrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private MedicineService medicineService;

    // Place Order
    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody OrderDTO orderDTO) {
        try {
            Order order = new Order();
            order.setCustomerName(orderDTO.getCustomerName());
            order.setCustomerEmail(orderDTO.getCustomerEmail());
            order.setCustomerPhone(orderDTO.getCustomerPhone());
            order.setDeliveryAddress(orderDTO.getDeliveryAddress());
            order.setStatus(OrderStatus.valueOf(orderDTO.getStatus()));
            order.setOrderDate(LocalDateTime.now());
            order.setTotalAmount(orderDTO.getTotalAmount());

            // Convert DTO items to Order items
            List<OrderItem> orderItems = orderDTO.getOrderItems().stream()
                .map(itemDTO -> {
                    Medicine medicine = medicineService.getMedicineById(itemDTO.getMedicine().getId())
                        .orElseThrow(() -> new RuntimeException("Medicine not found"));
                    
                    OrderItem item = new OrderItem();
                    item.setOrder(order);
                    item.setMedicine(medicine);
                    item.setQuantity(itemDTO.getQuantity());
                    item.setPrice(itemDTO.getPrice());
                    return item;
                })
                .collect(Collectors.toList());

            // Add items to order
            orderItems.forEach(order::addItem);

            return ResponseEntity.ok(orderService.createOrder(order));
        } catch (Exception e) {
            throw new RuntimeException("Failed to create order: " + e.getMessage());
        }
    }

    // Upload Prescription
    @PostMapping("/{orderId}/prescription")
    public ResponseEntity<Order> uploadPrescription(
            @PathVariable Long orderId,
            @RequestParam("file") MultipartFile prescriptionFile) {
        return ResponseEntity.ok(orderService.uploadPrescription(orderId, prescriptionFile));
    }

    // View Order History
    @GetMapping("/customer/{email}")
    public List<Order> getCustomerOrders(@PathVariable String email) {
        return orderService.getOrdersByCustomerEmail(email);
    }

    // View Single Order
    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable Long id) {
        return orderService.getOrderById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Cancel Order
    @PutMapping("/{id}/cancel")
    public ResponseEntity<Order> cancelOrder(@PathVariable Long id) {
        Order order = orderService.getOrderById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        // Only allow cancellation of pending or approved orders
        if (order.getStatus() != OrderStatus.PENDING_APPROVAL && 
            order.getStatus() != OrderStatus.APPROVED) {
            throw new RuntimeException("Cannot cancel order in " + order.getStatus() + " status");
        }
        
        return ResponseEntity.ok(orderService.updateOrderStatus(id, "CANCELLED"));
    }

    // View Orders by Status
    @GetMapping("/status/{status}")
    public List<Order> getOrdersByStatus(@PathVariable String status) {
        try {
            OrderStatus orderStatus = OrderStatus.valueOf(status.toUpperCase());
            return orderService.getOrdersByStatus(orderStatus);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Invalid order status: " + status);
        }
    }
} 
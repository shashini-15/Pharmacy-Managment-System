package com.pharmacy.service;

import com.pharmacy.model.Cart;
import com.pharmacy.model.Medicine;
import com.pharmacy.repository.CartRepository;
import com.pharmacy.repository.MedicineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private MedicineRepository medicineRepository;

    public Cart getCart(Long cartId) {
        return cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found"));
    }

    @Transactional
    public Cart addItemToCart(Long cartId, Long medicineId, int quantity) {
        Cart cart = getCart(cartId);
        Medicine medicine = medicineRepository.findById(medicineId)
                .orElseThrow(() -> new RuntimeException("Medicine not found"));

        cart.addItem(medicine, quantity);
        return cartRepository.save(cart);
    }

    @Transactional
    public Cart removeItemFromCart(Long cartId, Long medicineId) {
        Cart cart = getCart(cartId);
        cart.removeItem(medicineId);
        return cartRepository.save(cart);
    }

    @Transactional
    public Cart updateItemQuantity(Long cartId, Long medicineId, int quantity) {
        Cart cart = getCart(cartId);
        cart.updateQuantity(medicineId, quantity);
        return cartRepository.save(cart);
    }

    @Transactional
    public Cart clearCart(Long cartId) {
        Cart cart = getCart(cartId);
        cart.clear();
        return cartRepository.save(cart);
    }

    public Cart createCart() {
        Cart cart = new Cart();
        return cartRepository.save(cart);
    }
} 
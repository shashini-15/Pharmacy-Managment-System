package com.pharmacy.service;

import com.pharmacy.model.Medicine;
import com.pharmacy.repository.MedicineRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class MedicineService {

    private static final Logger logger = LoggerFactory.getLogger(MedicineService.class);

    @Autowired
    private MedicineRepository medicineRepository;

    @Transactional
    public Medicine createMedicine(Medicine medicine) {
        try {
            logger.info("Creating new medicine: {}", medicine);
            
            // Validate required fields
            validateMedicine(medicine);
            
            // Set default values if not provided
            if (medicine.getStockQuantity() == null) {
                medicine.setStockQuantity(0);
            }
            if (medicine.getDescription() == null) {
                medicine.setDescription("");
            }
            if (medicine.getImageUrl() == null || medicine.getImageUrl().trim().isEmpty()) {
                medicine.setImageUrl("default.jpg");
            }
            
            // Save the medicine
            Medicine savedMedicine = medicineRepository.save(medicine);
            logger.info("Medicine created successfully with ID: {}", savedMedicine.getId());
            
            return savedMedicine;
        } catch (Exception e) {
            logger.error("Error creating medicine: {}", e.getMessage());
            throw e;
        }
    }

    private void validateMedicine(Medicine medicine) {
        if (medicine.getName() == null || medicine.getName().trim().isEmpty()) {
            throw new RuntimeException("Medicine name is required");
        }
        if (medicine.getPrice() == null || medicine.getPrice().compareTo(BigDecimal.ZERO) <= 0) {
            throw new RuntimeException("Medicine price must be greater than zero");
        }
        if (medicine.getCategory() == null || medicine.getCategory().trim().isEmpty()) {
            throw new RuntimeException("Medicine category is required");
        }
        if (medicine.getRequiresPrescription() == null) {
            throw new RuntimeException("Prescription requirement must be specified");
        }
    }

    public List<Medicine> getAllMedicines() {
        return medicineRepository.findAll();
    }

    public Optional<Medicine> getMedicineById(Long id) {
        return medicineRepository.findById(id);
    }

    @Transactional
    public Medicine updateMedicine(Long id, Medicine medicineDetails) {
        try {
            logger.info("Updating medicine with ID: {}", id);
            
            Medicine medicine = medicineRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Medicine not found"));
            
            // Update fields
            medicine.setName(medicineDetails.getName());
            medicine.setDescription(medicineDetails.getDescription());
            medicine.setPrice(medicineDetails.getPrice());
            medicine.setStockQuantity(medicineDetails.getStockQuantity());
            medicine.setCategory(medicineDetails.getCategory());
            medicine.setManufacturer(medicineDetails.getManufacturer());
            medicine.setImageUrl(medicineDetails.getImageUrl());
            medicine.setRequiresPrescription(medicineDetails.getRequiresPrescription());
            
            // Validate the updated medicine
            validateMedicine(medicine);
            
            // Save the updated medicine
            Medicine updatedMedicine = medicineRepository.save(medicine);
            logger.info("Medicine updated successfully");
            
            return updatedMedicine;
        } catch (Exception e) {
            logger.error("Error updating medicine: {}", e.getMessage());
            throw e;
        }
    }

    @Transactional
    public void deleteMedicine(Long id) {
        try {
            logger.info("Deleting medicine with ID: {}", id);
            
            Medicine medicine = medicineRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Medicine not found"));
            
            medicineRepository.delete(medicine);
            logger.info("Medicine deleted successfully");
        } catch (Exception e) {
            logger.error("Error deleting medicine: {}", e.getMessage());
            throw e;
        }
    }

    public List<Medicine> searchMedicines(String query) {
        return medicineRepository.findByNameContainingIgnoreCase(query);
    }

    public List<Medicine> getMedicinesByCategory(String category) {
        return medicineRepository.findByCategory(category);
    }

    public List<Medicine> getMedicinesByPrescriptionRequirement(Boolean requiresPrescription) {
        return medicineRepository.findByRequiresPrescription(requiresPrescription);
    }
} 
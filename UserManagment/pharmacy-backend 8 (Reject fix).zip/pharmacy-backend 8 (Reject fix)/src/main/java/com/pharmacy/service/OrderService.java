package com.pharmacy.service;

import com.pharmacy.model.*;
import com.pharmacy.repository.MedicineRepository;
import com.pharmacy.repository.OrderRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class OrderService {
    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private MedicineRepository medicineRepository;

    @Value("${app.prescription.upload.dir:prescriptions}")
    private String prescriptionUploadDir;

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Optional<Order> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    public List<Order> getOrdersByCustomerEmail(String email) {
        return orderRepository.findByCustomerEmailOrderByOrderDateDesc(email);
    }

    public List<Order> getOrdersByStatus(OrderStatus status) {
        return orderRepository.findByStatus(status);
    }

    @Transactional
    public Order createOrder(Order order) {
        try {
            logger.info("Creating order for: {}", order.getCustomerName());
            logger.debug("Order items size: {}", order.getOrderItems() != null ? order.getOrderItems().size() : "null");
            
            // Validate order contains items
            if (order.getOrderItems() == null || order.getOrderItems().isEmpty()) {
                logger.error("Order items validation failed: Order items is null: {}", order.getOrderItems() == null);
                if (order.getOrderItems() != null) {
                    logger.error("Order items size: {}", order.getOrderItems().size());
                }
                throw new RuntimeException("Order must contain at least one item");
            }

            // order status
            if (order.getStatus() == null) {
                order.setStatus(OrderStatus.PENDING_APPROVAL);
            }

            // Set order date if not provided
            if (order.getOrderDate() == null) {
                order.setOrderDate(LocalDateTime.now());
            }

            // Calculate total amount 
            if (order.getTotalAmount() == null) {
                BigDecimal total = order.getOrderItems().stream()
                        .map(item -> item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
                order.setTotalAmount(total);
            }

            // Save the order with items
            Order savedOrder = orderRepository.save(order);
            logger.info("Order saved successfully with ID: {}", savedOrder.getId());
            
            return savedOrder;
        } catch (Exception ex) {
            logger.error("Error creating order: {}", ex.getMessage());
            throw new RuntimeException("Failed to create order: " + ex.getMessage(), ex);
        }
    }

    @Transactional
    public Order updateOrder(Long id, Order orderDetails) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        // Update orders
        order.setCustomerName(orderDetails.getCustomerName());
        order.setCustomerEmail(orderDetails.getCustomerEmail());
        order.setCustomerPhone(orderDetails.getCustomerPhone());
        order.setDeliveryAddress(orderDetails.getDeliveryAddress());
        order.setStatus(orderDetails.getStatus());
        order.setNotes(orderDetails.getNotes());

        // Update order items 
        if (orderDetails.getOrderItems() != null) {
            // Calculate total amount
            BigDecimal totalAmount = BigDecimal.ZERO;
            for (OrderItem item : orderDetails.getOrderItems()) {
                Medicine medicine = medicineRepository.findById(item.getMedicine().getId())
                        .orElseThrow(() -> new RuntimeException("Medicine not found"));
                
                // Check stock
                if (medicine.getStockQuantity() < item.getQuantity()) {
                    throw new RuntimeException("Insufficient stock for medicine: " + medicine.getName());
                }
                
                // Update stock
                medicine.setStockQuantity(medicine.getStockQuantity() - item.getQuantity());
                medicineRepository.save(medicine);
                
                // Set price and calculate total
                item.setPrice(medicine.getPrice());
                totalAmount = totalAmount.add(medicine.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())));
            }
            order.setOrderItems(orderDetails.getOrderItems());
            order.setTotalAmount(totalAmount);
        }

        return orderRepository.save(order);
    }

    @Transactional
    public Order uploadPrescription(Long orderId, MultipartFile prescriptionFile) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        try {
            // Create prescriptions directory
            Path uploadPath = Paths.get(prescriptionUploadDir).toAbsolutePath();
            logger.info("Upload path: {}", uploadPath);
            
            if (!Files.exists(uploadPath)) {
                logger.info("Creating prescriptions directory at: {}", uploadPath);
                Files.createDirectories(uploadPath);
            }

            // Generate filename
            String originalFilename = prescriptionFile.getOriginalFilename();
            logger.info("Original filename: {}", originalFilename);
            
            String extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            String filename = UUID.randomUUID().toString() + extension;
            Path filePath = uploadPath.resolve(filename);
            
            logger.info("Saving prescription file to: {}", filePath);

            // Save file
            Files.copy(prescriptionFile.getInputStream(), filePath, java.nio.file.StandardCopyOption.REPLACE_EXISTING);

            // Update order with prescription URL - store the complete URL path
            String prescriptionUrl = "/prescriptions/" + filename;  // Add leading slash for consistency
            logger.info("Setting prescription URL to: {}", prescriptionUrl);
            
            order.setPrescriptionImageUrl(prescriptionUrl);
            Order savedOrder = orderRepository.save(order);
            logger.info("Order updated successfully with prescription URL: {}", savedOrder.getPrescriptionImageUrl());
            return savedOrder;
        } catch (IOException e) {
            logger.error("Failed to store prescription file: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to store prescription file: " + e.getMessage(), e);
        }
    }

    @Transactional
    public Order updateOrderStatus(Long id, String status) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        try {
            OrderStatus newStatus = OrderStatus.valueOf(status.toUpperCase());
            order.setStatus(newStatus);
            return orderRepository.save(order);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Invalid order status: " + status);
        }
    }

    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }
}

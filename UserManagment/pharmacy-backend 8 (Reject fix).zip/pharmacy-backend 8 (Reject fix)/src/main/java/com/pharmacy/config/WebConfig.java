package com.pharmacy.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.lang.NonNull;
import java.nio.file.Path;
import java.nio.file.Paths;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    private static final Logger logger = LoggerFactory.getLogger(WebConfig.class);

    @Value("${app.prescription.upload.dir:prescriptions}")
    private String prescriptionUploadDir;

    @Override
    public void addResourceHandlers(@NonNull ResourceHandlerRegistry registry) {
        try {
            // Configure prescription file serving
            Path prescriptionUploadPath = Paths.get(prescriptionUploadDir).toAbsolutePath();
            String prescriptionUploadAbsolutePath = prescriptionUploadPath.toUri().toString();
            
            logger.info("Configuring prescription resource handler");
            logger.info("Prescription upload directory: {}", prescriptionUploadPath);
            logger.info("Prescription resource location: {}", prescriptionUploadAbsolutePath);
            
            // Add resource handler for prescription files
            registry.addResourceHandler("/prescriptions/**")
                    .addResourceLocations("file:" + prescriptionUploadAbsolutePath + "/")
                    .setCachePeriod(0) // Disable caching for development
                    .resourceChain(false); // Disable resource chain for development
            
            // Add resource handler for medicine images
            registry.addResourceHandler("/uploads/**")
                    .addResourceLocations("file:uploads/")
                    .setCachePeriod(0)
                    .resourceChain(false);
            
            logger.info("Resource handlers configured successfully");
        } catch (Exception e) {
            logger.error("Failed to configure resource handlers: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to configure resource handlers", e);
        }
    }
} 